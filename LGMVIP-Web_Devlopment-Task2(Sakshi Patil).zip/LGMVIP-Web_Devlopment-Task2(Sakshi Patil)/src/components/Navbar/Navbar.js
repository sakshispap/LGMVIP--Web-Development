import './Navbar.css'
import React from 'react'
import { Button } from 'react-bootstrap';

const Navbar = ({ buttonclicked }) => {
    const clicked = () => {
        buttonclicked(true);
    }
    return (
        <nav className="NavbarItems">
            <h1 className="navbar-logo"><strong>USER-DATA-BLOG</strong></h1>
            <Button className="nav-button" onClick={clicked}><strong>CLICK-ME</strong></Button>
        </nav>
     
    )
   
}
export default Navbar;